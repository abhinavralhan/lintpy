from setuptools import setup
setup(name='lintpy',
      version='0.1',
      description='The funniest joke in the world',
      url='http://github.com/abhinavralhan/lintpy',
      author='abhinavralhan',
      author_email='abhinav.ralhan1@gmail.com',
      license='MIT',
      packages=['lintpy'],
      zip_safe=False)
